// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package org.jetbrains.java.decompiler.modules.decompiler;

import org.jetbrains.java.decompiler.code.CodeConstants;
import org.jetbrains.java.decompiler.main.DecompilerContext;
import org.jetbrains.java.decompiler.main.collectors.CounterContainer;
import org.jetbrains.java.decompiler.main.extern.IFernflowerPreferences;
import org.jetbrains.java.decompiler.modules.decompiler.exps.*;
import org.jetbrains.java.decompiler.modules.decompiler.exps.FunctionExprent.FunctionType;
import org.jetbrains.java.decompiler.modules.decompiler.stats.IfStatement;
import org.jetbrains.java.decompiler.modules.decompiler.stats.Statement;
import org.jetbrains.java.decompiler.modules.decompiler.vars.VarProcessor;
import org.jetbrains.java.decompiler.modules.decompiler.vars.VarVersionPair;
import org.jetbrains.java.decompiler.struct.gen.CodeType;
import org.jetbrains.java.decompiler.struct.gen.TypeFamily;
import org.jetbrains.java.decompiler.struct.gen.VarType;

import java.util.*;

public final class SecondaryFunctionsHelper {
  private static final IdentifySecondaryOptions DEFAULT_OPTIONS = new IdentifySecondaryOptions();

  private static final Map<FunctionType, FunctionType> funcsnot = new HashMap<>();

  static {
    funcsnot.put(FunctionType.EQ, FunctionType.NE);
    funcsnot.put(FunctionType.NE, FunctionType.EQ);
    funcsnot.put(FunctionType.LT, FunctionType.GE);
    funcsnot.put(FunctionType.GE, FunctionType.LT);
    funcsnot.put(FunctionType.GT, FunctionType.LE);
    funcsnot.put(FunctionType.LE, FunctionType.GT);
    funcsnot.put(FunctionType.BOOLEAN_AND, FunctionType.BOOLEAN_OR);
    funcsnot.put(FunctionType.BOOLEAN_OR, FunctionType.BOOLEAN_AND);
  }

  private static final HashMap<FunctionType, FunctionType[]> mapNumComparisons = new HashMap<>();

  static {
    mapNumComparisons.put(FunctionType.EQ, new FunctionType[]{FunctionType.LT, FunctionType.EQ, FunctionType.GT});
    mapNumComparisons.put(FunctionType.NE, new FunctionType[]{FunctionType.GE, FunctionType.NE, FunctionType.LE});
    mapNumComparisons.put(FunctionType.GT, new FunctionType[]{FunctionType.GE, FunctionType.GT, null});
    mapNumComparisons.put(FunctionType.GE, new FunctionType[]{null, FunctionType.GE, FunctionType.GT});
    mapNumComparisons.put(FunctionType.LT, new FunctionType[]{null, FunctionType.LT, FunctionType.LE});
    mapNumComparisons.put(FunctionType.LE, new FunctionType[]{FunctionType.LT, FunctionType.LE, null});
  }

  public static boolean identifySecondaryFunctions(Statement stat, VarProcessor varProc) {
    return identifySecondaryFunctions(stat, varProc, DEFAULT_OPTIONS);
  }

  public static boolean identifySecondaryFunctions(Statement stat, VarProcessor varProc, IdentifySecondaryOptions options) {
    if (stat.getExprents() == null) {
      // if(){;}else{...} -> if(!){...}
      if (stat instanceof IfStatement) {
        IfStatement ifelsestat = (IfStatement) stat;
        Statement ifstat = ifelsestat.getIfstat();

        if (ifelsestat.iftype == IfStatement.IFTYPE_IFELSE && ifstat.getExprents() != null &&
          ifstat.getExprents().isEmpty() && (ifstat.getAllSuccessorEdges().isEmpty() || !ifstat.getFirstSuccessor().explicit)) {

          // move else to the if position
          ifelsestat.getStats().removeWithKey(ifstat.id);

          ifelsestat.iftype = IfStatement.IFTYPE_IF;
          ifelsestat.setIfstat(ifelsestat.getElsestat());
          ifelsestat.setElsestat(null);

          if (ifelsestat.getAllSuccessorEdges().isEmpty() && !ifstat.getAllSuccessorEdges().isEmpty()) {
            StatEdge endedge = ifstat.getFirstSuccessor();

            ifstat.removeSuccessor(endedge);
            endedge.setSource(ifelsestat);
            if (endedge.closure != null) {
              ifelsestat.getParent().addLabeledEdge(endedge);
            }
            ifelsestat.addSuccessor(endedge);
          }

          ifelsestat.getFirst().removeSuccessor(ifelsestat.getIfEdge());

          ifelsestat.setIfEdge(ifelsestat.getElseEdge());
          ifelsestat.setElseEdge(null);

          // negate head expression
          ifelsestat.setNegated(!ifelsestat.isNegated());
          ifelsestat.getHeadexprentList().set(0, ((IfExprent) ifelsestat.getHeadexprent().copy()).negateIf());

          return true;
        } else if (ifelsestat.iftype == IfStatement.IFTYPE_IF && ifstat != null && ifstat.getExprents() != null &&
          ifstat.getExprents().isEmpty() && (ifstat.hasAnySuccessor() && ifstat.getFirstSuccessor().getType() == StatEdge.TYPE_FINALLYEXIT)) {

          // Inlining blocks into finally statements will cause some if statements to have inconsistent semantics.
          // A block with a finallyexit can be inlined via InlineSingleBlocks to where a break once was, making improper control flow
          // e.g.
          // if (!<cond>) {
          //   ;
          // }
          // break;
          //
          // becomes
          //
          // if (<cond>) {
          //   break;
          // }
          // When inside a finally
          // FIXME: fix the underlying issue here
          // see also: TestLoopFinally


//          if (ifelsestat.hasSuccessor(StatEdge.TYPE_BREAK)) {
//
//            SequenceHelper.destroyStatementContent(ifstat, true);
//            ifelsestat.setIfstat(null);
//
//            StatEdge edge = ifelsestat.getSuccessorEdges(StatEdge.TYPE_BREAK).get(0);
//
//            edge.changeSource(ifelsestat.getFirst());
//
//            ifelsestat.setIfEdge(edge);
//
//            // negate head expression
//            ifelsestat.setNegated(!ifelsestat.isNegated());
//            ifelsestat.getHeadexprentList().set(0, ((IfExprent)ifelsestat.getHeadexprent().copy()).negateIf());
//          }

        }
      }
    }

    boolean ret = false;
    boolean replaced = true;
    while (replaced) {
      replaced = false;

      List<Object> lstObjects = new ArrayList<>(stat.getExprents() == null ? stat.getSequentialObjects() : stat.getExprents());

      for (int i = 0; i < lstObjects.size(); i++) {
        Object obj = lstObjects.get(i);

        if (obj instanceof Statement) {
          if (identifySecondaryFunctions((Statement) obj, varProc, options)) {
            ret = true;
            replaced = true;
            break;
          }
        } else if (obj instanceof Exprent) {
          Exprent retexpr = identifySecondaryFunctions(stat, (Exprent) obj, true, varProc, options);
          if (retexpr != null) {
            if (stat.getExprents() == null) {
              // only head expressions can be replaced!
              stat.replaceExprent((Exprent) obj, retexpr);
            } else {
              stat.getExprents().set(i, retexpr);
            }
            ret = true;
            replaced = true;
            break;
          }
        }
      }
    }

    return ret;
  }

  private static Exprent identifySecondaryFunctions(Statement stat, Exprent exprent, boolean statement_level, VarProcessor varProc, IdentifySecondaryOptions options) {
    if (exprent instanceof FunctionExprent) {
      FunctionExprent fexpr = (FunctionExprent) exprent;

      switch (fexpr.getFuncType()) {
        case BOOL_NOT:

          Exprent retparam = propagateBoolNot(fexpr);

          if (retparam != null) {
            return retparam;
          }

          break;
        case EQ:
        case NE:
        case GT:
        case GE:
        case LT:
        case LE:
          Exprent expr1 = fexpr.getLstOperands().get(0);
          Exprent expr2 = fexpr.getLstOperands().get(1);

          if (expr1 instanceof ConstExprent) {
            expr2 = expr1;
            expr1 = fexpr.getLstOperands().get(1);
          }

          if (expr1 instanceof FunctionExprent && expr2 instanceof ConstExprent) {
            FunctionExprent funcexpr = (FunctionExprent) expr1;
            ConstExprent cexpr = (ConstExprent) expr2;

            FunctionType functype = funcexpr.getFuncType();
            if (functype == FunctionType.LCMP || functype == FunctionType.FCMPG ||
              functype == FunctionType.FCMPL || functype == FunctionType.DCMPG ||
              functype == FunctionType.DCMPL) {

              FunctionType desttype = null;

              FunctionType[] destcons = mapNumComparisons.get(fexpr.getFuncType());
              if (destcons != null) {
                int index = cexpr.getIntValue() + 1;
                if (index >= 0 && index <= 2) {
                  FunctionType destcon = destcons[index];
                  if (destcon != null) {
                    desttype = destcon;
                  }
                }
              }

              if (desttype != null) {
                if (functype != FunctionType.LCMP) {
                  boolean oneForNan = functype == FunctionType.DCMPL || functype == FunctionType.FCMPL;
                  boolean trueForOne = desttype == FunctionType.LT || desttype == FunctionType.LE;
                  boolean trueForNan = oneForNan == trueForOne;
                  if (trueForNan) {
                    List<Exprent> operands = new ArrayList<>();
                    operands.add(new FunctionExprent(funcsnot.get(desttype), funcexpr.getLstOperands(), funcexpr.bytecode));
                    return new FunctionExprent(FunctionType.BOOL_NOT, operands, funcexpr.bytecode);
                  }
                }
                return new FunctionExprent(desttype, funcexpr.getLstOperands(), funcexpr.bytecode);
              }
            }
          }
          break;
        // if ++i or --i is being used as a statement rather than expression we may replace with i++/i--
        case PPI:
          if (statement_level) {
            FunctionExprent func = new FunctionExprent(FunctionType.IPP, fexpr.getLstOperands(), fexpr.bytecode);
            func.setImplicitType(fexpr.getExprType());
            return func;
          }
          break;
        case MMI:
          if (statement_level) {
            FunctionExprent func = new FunctionExprent(FunctionType.IMM, fexpr.getLstOperands(), fexpr.bytecode);
            func.setImplicitType(fexpr.getExprType());
            return func;
          }
          break;
      }
    }

    Exprent ret = null;

    boolean replaced = true;
    while (replaced) {
      replaced = false;

      for (Exprent expr : exprent.getAllExprents()) {
        Exprent retexpr = identifySecondaryFunctions(stat, expr, false, varProc, options);
        if (retexpr != null) {
          exprent.replaceExprent(expr, retexpr);
          retexpr.addBytecodeOffsets(expr.bytecode);
          replaced = true;
          ret = exprent;
          break;
        }
      }
    }

    switch (exprent.type) {
      case FUNCTION:
        FunctionExprent fexpr = (FunctionExprent) exprent;
        List<Exprent> lstOperands = fexpr.getLstOperands();

        switch (fexpr.getFuncType()) {
          case XOR:
            for (int i = 0; i < 2; i++) {
              Exprent operand = lstOperands.get(i);
              VarType operandtype = operand.getExprType();

              if (operand instanceof ConstExprent &&
                operandtype.type != CodeType.BOOLEAN) {
                ConstExprent cexpr = (ConstExprent) operand;
                long val;
                if (operandtype.type == CodeType.LONG) {
                  val = (Long) cexpr.getValue();
                } else {
                  val = (Integer) cexpr.getValue();
                }

                if (val == -1) {
                  List<Exprent> lstBitNotOperand = new ArrayList<>();
                  lstBitNotOperand.add(lstOperands.get(1 - i));
                  return new FunctionExprent(FunctionType.BIT_NOT, lstBitNotOperand, fexpr.bytecode);
                }
              }
            }
            break;
          case EQ:
          case NE:
            if (lstOperands.get(0).getExprType().type == CodeType.BOOLEAN &&
              lstOperands.get(1).getExprType().type == CodeType.BOOLEAN) {
              for (int i = 0; i < 2; i++) {
                if (lstOperands.get(i) instanceof ConstExprent) {
                  ConstExprent cexpr = (ConstExprent) lstOperands.get(i);
                  int val = (Integer) cexpr.getValue();

                  if ((fexpr.getFuncType() == FunctionType.EQ && val == 1) ||
                    (fexpr.getFuncType() == FunctionType.NE && val == 0)) {
                    return lstOperands.get(1 - i);
                  } else {
                    List<Exprent> lstNotOperand = new ArrayList<>();
                    lstNotOperand.add(lstOperands.get(1 - i));
                    return new FunctionExprent(FunctionType.BOOL_NOT, lstNotOperand, fexpr.bytecode);
                  }
                }
              }
            }
            break;
          case BOOL_NOT:
            if (lstOperands.get(0) instanceof ConstExprent) {
              int val = ((ConstExprent) lstOperands.get(0)).getIntValue();
              if (val == 0) {
                return new ConstExprent(VarType.VARTYPE_BOOLEAN, 1, fexpr.bytecode);
              } else {
                return new ConstExprent(VarType.VARTYPE_BOOLEAN, 0, fexpr.bytecode);
              }
            }
            break;
          case TERNARY:
            Exprent expr0 = lstOperands.get(0);
            Exprent expr1 = lstOperands.get(1);
            Exprent expr2 = lstOperands.get(2);

            if (expr1 instanceof ConstExprent && expr2 instanceof ConstExprent) {
              ConstExprent cexpr1 = (ConstExprent) expr1;
              ConstExprent cexpr2 = (ConstExprent) expr2;

              if (cexpr1.getExprType().type == CodeType.BOOLEAN &&
                cexpr2.getExprType().type == CodeType.BOOLEAN) {

                if (cexpr1.getIntValue() == 0 && cexpr2.getIntValue() != 0) {
                  return new FunctionExprent(FunctionType.BOOL_NOT, lstOperands.get(0), fexpr.bytecode);
                } else if (cexpr1.getIntValue() != 0 && cexpr2.getIntValue() == 0) {
                  return lstOperands.get(0);
                }
              }
            }

            if (DecompilerContext.getOption(IFernflowerPreferences.TERNARY_CONSTANT_SIMPLIFICATION) || options.forceTernarySimplification) {
              if (expr1 instanceof ConstExprent && expr1.getExprType().type == CodeType.BOOLEAN) {
                ConstExprent cexpr1 = (ConstExprent) expr1;
                boolean val = cexpr1.getIntValue() != 0;

                if (val) {
                  // bl ? true : bl2 <-> bl || bl2
                  return new FunctionExprent(FunctionType.BOOLEAN_OR, Arrays.asList(lstOperands.get(0), lstOperands.get(2)), fexpr.bytecode);
                } else {
                  // bl ? false : bl2 <-> !bl && bl2
                  FunctionExprent fnot = new FunctionExprent(FunctionType.BOOL_NOT, lstOperands.get(0), fexpr.bytecode);
                  return new FunctionExprent(FunctionType.BOOLEAN_AND, Arrays.asList(fnot, lstOperands.get(2)), fexpr.bytecode);
                }
              } else if (expr2 instanceof ConstExprent && expr2.getExprType().type == CodeType.BOOLEAN) {
                ConstExprent cexpr2 = (ConstExprent) expr2;
                boolean val = cexpr2.getIntValue() != 0;

                if (val) {
                  // bl ? bl2 : true <-> !bl || bl2
                  FunctionExprent fnot = new FunctionExprent(FunctionType.BOOL_NOT, lstOperands.get(0), fexpr.bytecode);
                  return new FunctionExprent(FunctionType.BOOLEAN_OR, Arrays.asList(fnot, lstOperands.get(1)), fexpr.bytecode);
                } else {
                  // bl ? bl2 : false <-> bl && bl2
                  return new FunctionExprent(FunctionType.BOOLEAN_AND, Arrays.asList(lstOperands.get(0), lstOperands.get(1)), fexpr.bytecode);
                }
              } else if (expr1.getExprType().type == CodeType.BOOLEAN && expr1.equals(expr0)) {
                // bl ? bl : bl2 <-> bl || bl2
                return new FunctionExprent(FunctionType.BOOLEAN_OR, Arrays.asList(lstOperands.get(0), lstOperands.get(2)), fexpr.bytecode);
              } else if (expr2.getExprType().type == CodeType.BOOLEAN && expr2.equals(expr0)) {
                // bl ? bl2 : bl <-> bl && bl2
                return new FunctionExprent(FunctionType.BOOLEAN_AND, Arrays.asList(lstOperands.get(0), lstOperands.get(1)), fexpr.bytecode);
              }
            }
            break;
          case LCMP:
          case FCMPL:
          case FCMPG:
          case DCMPL:
          case DCMPG:
            int var = DecompilerContext.getCounterContainer().getCounterAndIncrement(CounterContainer.VAR_COUNTER);
            VarType type = lstOperands.get(0).getExprType();

            FunctionExprent iff = new FunctionExprent(FunctionType.TERNARY, Arrays.asList(
              new FunctionExprent(FunctionType.LT, Arrays.asList(new VarExprent(var, type, varProc),
                ConstExprent.getZeroConstant(type.type)), null),
              new ConstExprent(VarType.VARTYPE_INT, -1, null),
              new ConstExprent(VarType.VARTYPE_INT, 1, null)), null);

            FunctionExprent head = new FunctionExprent(FunctionType.EQ, Arrays.asList(
              new AssignmentExprent(new VarExprent(var, type, varProc),
                new FunctionExprent(FunctionType.SUB, Arrays.asList(lstOperands.get(0), lstOperands.get(1)), null),
                null),
              ConstExprent.getZeroConstant(type.type)), null);

            varProc.setVarType(new VarVersionPair(var, 0), type);

            return new FunctionExprent(FunctionType.TERNARY, Arrays.asList(
              head, new ConstExprent(VarType.VARTYPE_INT, 0, null), iff), fexpr.bytecode);
          case I2B:
          case I2C:
          case I2S:
            if (lstOperands.get(0) instanceof FunctionExprent) {
              FunctionExprent innerFunction = (FunctionExprent) lstOperands.get(0);
              VarType castType = innerFunction.getFuncType().castType;
              if (castType == VarType.VARTYPE_INT) {
                // longs, floats and doubles are converted to ints before being converted to bytes, shorts or chars
                innerFunction.setNeedsCast(false);
                return ret;
              }
            }
            // fallthrough
          case I2L:
          case I2F:
          case I2D:
          case L2F:
          case L2D:
          case F2D:
            VarType exprType = lstOperands.get(0).getExprType();
            VarType castType = fexpr.getSimpleCastType();

            // Simplify widening cast
            if (castType.typeFamily == TypeFamily.INTEGER) {
              if (castType.isStrictSuperset(exprType)) {
                fexpr.setNeedsCast(false);
                return ret;
              }
            } else if (castType.typeFamily.isGreater(exprType.typeFamily)) {
              fexpr.setNeedsCast(false);
              return ret;
            }
            break;
          case ADD:
          case SUB:
          case MUL:
          case DIV:
            Exprent left = lstOperands.get(0);
            boolean leftImplicitCast = left instanceof FunctionExprent && ((FunctionExprent) left).getSimpleCastType() != null && !((FunctionExprent) left).doesCast();
            Exprent right = lstOperands.get(1);
            boolean rightImplicitCast = right instanceof FunctionExprent && ((FunctionExprent) right).getSimpleCastType() != null && !((FunctionExprent) right).doesCast();

            if (leftImplicitCast && rightImplicitCast && right.getExprType() == left.getExprType()) {
              // Only a single cast is needed explicitly
              ((FunctionExprent) left).setNeedsCast(true);
            }
            break;
          case SHL:
          case SHR:
          case USHR:
            Exprent op = lstOperands.get(0);
            if (op instanceof FunctionExprent && ((FunctionExprent) op).getSimpleCastType() != null && !((FunctionExprent) op).doesCast()) {
              ((FunctionExprent) op).setNeedsCast(true);
            }
        }
        break;
      case ASSIGNMENT: // check for conditional assignment
        AssignmentExprent asexpr = (AssignmentExprent) exprent;

        if (asexpr.getCondType() != null)
          return ret;

        Exprent right = asexpr.getRight();
        Exprent left = asexpr.getLeft();

        if (right instanceof FunctionExprent) {
          FunctionExprent func = (FunctionExprent) right;
          if (isSimple(left, null)) {

            VarType midlayer = null;
            if (func.getFuncType().castType != null) {
              right = func.getLstOperands().get(0);
              midlayer = func.getSimpleCastType();
              if (right instanceof FunctionExprent) {
                func = (FunctionExprent) right;
              } else {
                return ret;
              }
            }

            List<Exprent> lstFuncOperands = func.getLstOperands();

            Exprent cond = null;

            switch (func.getFuncType()) {
              case ADD:
              case AND:
              case OR:
              case XOR:
                // FIXME: only do this if the cond is pure
                if (left.equals(lstFuncOperands.get(1))) {
                  cond = lstFuncOperands.get(0);
                  break;
                }
              case SUB:
              case MUL:
              case DIV:
              case REM:
              case SHL:
              case SHR:
              case USHR:
                if (left.equals(lstFuncOperands.get(0))) {
                  cond = lstFuncOperands.get(1);
                }
            }

            if (cond != null && (midlayer == null || midlayer.equals(cond.getExprType())) && isSimple(left, cond)) {
              asexpr.setRight(cond);
              asexpr.setCondType(func.getFuncType());
              // changed
              ret = exprent;
            }
          }
        }
        break;
      case INVOCATION:
        InvocationExprent invocationExpr = (InvocationExprent) exprent;
        if (invocationExpr.isBoxingCall()) {
          Exprent param = invocationExpr.getLstParameters().get(0);
          // Keep casts of boxed exprents
          if (param instanceof FunctionExprent && ((FunctionExprent) param).getSimpleCastType() != null && !((FunctionExprent) param).doesCast()) {
            ((FunctionExprent) param).setNeedsCast(true);
          }
        }

        if (!statement_level) { // simplify if exprent is a real expression. The opposite case is pretty absurd, can still happen however (and happened at least once).
          Exprent retexpr = ConcatenationHelper.contractStringConcat(stat.getTopParent(), exprent);
          if (!exprent.equals(retexpr)) {
            return retexpr;
          }
        } else {
          // Force boxing at statement level, wouldn't want a 3; just lying around
          InvocationExprent invocationExprent = (InvocationExprent) exprent;
          if (invocationExprent.isBoxingCall()) {
            invocationExprent.forceBoxing(true);
          }
        }
    }

    return ret;
  }

  // whether `exprent = exprent + ...` can be simplified to `exprent += ...`
  private static boolean isSimple(Exprent exprent, Exprent other) {
    switch (exprent.type) {
      case VAR:
      case CONST: {
        return true;
      }
      case ARRAY: {
        ArrayExprent array = (ArrayExprent) exprent;
        return isSuperSimple(array.getIndex()) && isSuperSimple(array.getArray());
      }
      case FIELD: {
        if (other == null) {
          return true;
        }
        return ((other.getExprentUse() & Exprent.SIDE_EFFECTS_FREE) != 0);
      }
      default: {
        return false;
      }
    }
  }

  private static boolean isSuperSimple(Exprent exprent) {
    return exprent.type == Exprent.Type.VAR || exprent.type == Exprent.Type.CONST;
  }

  private static boolean hasPattern(Exprent exprent) {
    for (Exprent ex : exprent.getAllExprents(false, true)) {
      if (ex instanceof PatternExprent || ex instanceof FunctionExprent func && func.getFuncType() == FunctionType.INSTANCEOF && func.getLstOperands().size() > 2) {
        return true;
      }
    }

    return false;
  }

  public static Exprent propagateBoolNot(Exprent exprent) {

    if (exprent instanceof FunctionExprent) {
      FunctionExprent fexpr = (FunctionExprent) exprent;

      if (fexpr.getFuncType() == FunctionType.BOOL_NOT) {

        Exprent param = fexpr.getLstOperands().get(0);

        if (param instanceof FunctionExprent fparam) {

          FunctionType ftype = fparam.getFuncType();
          // Can't change any patterns, except for nested '!' which we can peek through
          if (hasPattern(fparam) && ftype != FunctionType.BOOL_NOT) {
            return null;
          }
          boolean canSimplify = false;
          switch (ftype) {
            case BOOL_NOT:
              Exprent newexpr = fparam.getLstOperands().get(0);
              Exprent retexpr = propagateBoolNot(newexpr);
              return retexpr == null ? newexpr : retexpr;
            case TERNARY:
              // Wrap branches
              FunctionExprent fex1 = new FunctionExprent(FunctionType.BOOL_NOT, fparam.getLstOperands().get(1), null);
              FunctionExprent fex2 = new FunctionExprent(FunctionType.BOOL_NOT, fparam.getLstOperands().get(2), null);

              // Propagate both branches
              Exprent ex1 = propagateBoolNot(fex1);
              Exprent ex2 = propagateBoolNot(fex2);

              // Set both branches to new version if it was created, or old if it wasn't
              fparam.getLstOperands().set(1, ex1 == null ? fex1 : ex1);
              fparam.getLstOperands().set(2, ex2 == null ? fex2 : ex2);

              return fparam;
            case BOOLEAN_AND:
            case BOOLEAN_OR:
              List<Exprent> operands = fparam.getLstOperands();
              for (int i = 0; i < operands.size(); i++) {
                Exprent newparam = new FunctionExprent(FunctionType.BOOL_NOT, operands.get(i), operands.get(i).bytecode);

                Exprent retparam = propagateBoolNot(newparam);
                operands.set(i, retparam == null ? newparam : retparam);
              }
            case EQ:
            case NE:
              canSimplify = true;
            case LT:
            case GE:
            case GT:
            case LE:
              if (!canSimplify) {
                operands = fparam.getLstOperands();
                VarType left = operands.get(0).getExprType();
                VarType right = operands.get(1).getExprType();
                VarType commonSupertype = VarType.getCommonSupertype(left, right);
                if (commonSupertype != null) {
                  canSimplify = commonSupertype.type != CodeType.FLOAT && commonSupertype.type != CodeType.DOUBLE;
                }
              }
              if (canSimplify) {
                fparam.setFuncType(funcsnot.get(ftype));
                return fparam;
              }
          }
        }
      }
    }

    return null;
  }

  /**
   * Simplifies assignment exprents that can be represented as a compound assignment.
   * Example: "a = a + b" becomes "a += b"
   * Iterates recursively through every statement within the statement and all assignments possible.
   * See: <a href="https://docs.oracle.com/javase/specs/jls/se16/html/jls-15.html#jls-15.26.2">JLS-15.26.2</a>
   *
   * @param stat The provided statement
   */
  public static boolean updateAssignments(Statement stat) {
    boolean res = false;
    // Get all sequential objects if the statement doesn't have exprents
    List<Object> objects = new ArrayList<>(stat.getExprents() == null ? stat.getSequentialObjects() : stat.getExprents());

    for (Object obj : objects) {
      if (obj instanceof Statement) {
        // If the object is a statement, recurse
        res |= updateAssignments((Statement) obj);
      } else if (obj instanceof Exprent) {
        // If the statement is an exprent, start processing
        Exprent exprent = (Exprent) obj;

        if (exprent instanceof AssignmentExprent) {
          AssignmentExprent assignment = (AssignmentExprent) exprent;

          List<Exprent> params = exprent.getAllExprents();

          // Get params of the assignment exprent
          Exprent lhs = params.get(0);
          Exprent rhs = params.get(1);

          // We only want expressions that are standard assignments where the left hand side is a variable and the right hand side is a function.
          if (assignment.getCondType() == null && lhs instanceof VarExprent && rhs instanceof FunctionExprent) {
            VarExprent lhsVar = (VarExprent) lhs;
            FunctionExprent rhsFunc = (FunctionExprent) rhs;

            List<Exprent> funcParams = rhsFunc.getAllExprents();

            // Make sure that the function is a mathematical or bit shift function
            if (rhsFunc.getFuncType().isArithmeticBinaryOperation() && funcParams.get(0) instanceof VarExprent) {
              // Get the left hand side of the function
              VarExprent lhsVarFunc = (VarExprent) funcParams.get(0);

              // Check if the left hand side of the assignment and the left hand side of the function are the same variable
              // TODO: maybe we should be checking for var version equality too?
              if (lhsVar.getIndex() == lhsVarFunc.getIndex()) {
                // If all the checks succeed, set the assignment to be a compound assignment and set the right hand side to be the 2nd part of the function
                assignment.setCondType(rhsFunc.getFuncType());
                assignment.setRight(funcParams.get(1));
                // TODO: doesn't hit all instances, see ClientWorld

                res = true;
              }
            }
          }
        }
      }
    }

    return res;
  }

  public static class IdentifySecondaryOptions {
    private boolean forceTernarySimplification = false;

    public IdentifySecondaryOptions forceTernarySimplification() {
      forceTernarySimplification = true;

      return this;
    }
  }
}
